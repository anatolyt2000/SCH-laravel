<?php
class country extends Eloquent {
	public $timestamps = false;
	protected $table = 'country';
}