<?php
class expenses extends Eloquent {
	public $timestamps = false;
	protected $table = 'expenses';
}
