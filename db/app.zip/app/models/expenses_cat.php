<?php
class expenses_cat extends Eloquent {
	public $timestamps = false;
	protected $table = 'expenses_cat';
}
