<?php
class hostel_cat extends Eloquent {
	public $timestamps = false;
	protected $table = 'hostel_cat';
}
