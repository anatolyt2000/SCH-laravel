<?php
class mailsms extends Eloquent {
	public $timestamps = false;
	protected $table = 'mailsms';
}