<?php
class media_albums extends Eloquent {
	public $timestamps = false;
	protected $table = 'media_albums';
}
