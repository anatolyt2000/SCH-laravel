<?php
class media_items extends Eloquent {
	public $timestamps = false;
	protected $table = 'media_items';
}
