<?php
class polls extends Eloquent {
	public $timestamps = false;
	protected $table = 'polls';
}