<?php
class religions extends Eloquent {
	public $timestamps = false;
	protected $table = 'religions';
}