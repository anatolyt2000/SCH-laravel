<?php
class subject extends Eloquent {
	public $timestamps = false;
	protected $table = 'subject';
}