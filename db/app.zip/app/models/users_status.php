<?php
class users_status extends Eloquent {
	public $timestamps = false;
	protected $table = 'users_status';
}